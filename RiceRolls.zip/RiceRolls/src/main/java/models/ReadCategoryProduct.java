package models;

import java.util.TreeMap;
import models.Product;

public class ReadCategoryProduct {

    //準備好產品清單  
    public static TreeMap<String, Product> readProduct() {
        //read_product_from_file(); //從檔案或資料庫讀入產品菜單資訊
        //放所有產品  產品編號  產品物件
        TreeMap<String, Product> product_dict = new TreeMap<>();
        String[][] product_array = {
            {"p-j-101", "葷飯捲", "玉米肉鬆", "50", "cornfloss.jpg", "玉米搭配肉鬆的好滋味"},
            {"p-j-102", "葷飯捲", "鮪魚起司", "55", "TunaCheese.jpg", "鮮味加濃郁的絕佳組合"},
            {"p-j-103", "葷飯捲", "煙燻培根", "55", "smokedbacon.jpg", "煙燻過後的培根香氣十足"},
            {"p-j-104", "葷飯捲", "和風燒肉", "60", "roastedpork.jpg", "烤過的豬肉刷上和風醬"},
            {"p-j-105", "葷飯捲", "煙燻雞肉", "60", "SmokedChicken.jpeg", "煙燻過後的雞肉別有一番滋味"},
            {"p-j-106", "素飯捲", "香筍牛蒡", "50", "BamboosShootsAndBurdock.jpg", "牛蒡愛好者首選"},
            {"p-j-107", "素飯捲", "生機蔬菜", "50", "RawVegetables.jpg", "給喜歡蔬菜的你"},
            {"p-j-108", "素飯捲", "素肉燥", "55", "VegetarianBraisedPork.jpg", "「食肉」愛好者首選"},
            {"p-j-109", "素飯捲", "素火腿", "55", "VegetarianHam.jpg", "吃起來就跟真的肉一樣"},
            {"p-j-110", "素飯捲", "煙燻素烤鴨", "55", "SmokedVegetarianRoastDuck.jpg", "愚人節比買單品"},
        };

        //一筆放入字典變數product_dict中
        for (String[] item : product_array) {
            Product product = new Product(
                    item[0],
                    item[1],
                    item[2],
                    Integer.parseInt(item[3]), //價格轉為int
                    item[4],
                    item[5]);
            //將這一筆放入字典變數product_dict中 
            product_dict.put(product.getProduct_id(), product);
        }
        return product_dict;
    }
}
