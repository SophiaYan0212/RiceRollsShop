module mypos {
requires javafx.controls;
    requires javafx.base;
    requires javafx.graphics;
    exports mypos; //mypos主要程式套件目錄
    exports models; //models模型套件目錄

}
